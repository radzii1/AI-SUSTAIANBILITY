import pandas as pd
import matplotlib.pyplot as plt
import zipfile
import urllib.request
import os

# Step 1: Download and extract the dataset
dataset_url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/00235/household_power_consumption.zip'
zip_file = 'household_power_consumption.zip'
data_file = 'household_power_consumption.txt'

# Download if not already there
if not os.path.exists(zip_file):
    print("Downloading dataset...")
    urllib.request.urlretrieve(dataset_url, zip_file)

# Unzip if not already extracted
if not os.path.exists(data_file):
    print("Extracting dataset...")
    with zipfile.ZipFile(zip_file, 'r') as zip_ref:
        zip_ref.extractall()

# Step 2: Load the dataset
print("Loading data...")
df = pd.read_csv(
    data_file,
    sep=';',
    parse_dates={'Datetime': ['Date', 'Time']},
    infer_datetime_format=True,
    na_values='?',
    low_memory=False
)

# Step 3: Convert types and drop missing
df = df.dropna()
df['Global_active_power'] = df['Global_active_power'].astype(float)

# Step 4: Sample down to daily mean to simplify for beginner visualization
df.set_index('Datetime', inplace=True)
daily_power = df['Global_active_power'].resample('D').mean()

# Step 5: Plot the data and save the image
plt.figure(figsize=(12, 5))
plt.plot(daily_power.index, daily_power.values, label='Daily Avg Global Active Power (kW)')
plt.title('Daily Electricity Usage Trend')
plt.xlabel('Date')
plt.ylabel('Power (kilowatts)')
plt.legend()
plt.tight_layout()
plt.grid(True)
plt.savefig("screenshot.png")
plt.show()
