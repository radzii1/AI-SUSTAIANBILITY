# Energy Usage Visualization

This Python project visualizes daily electricity usage from the UCI Household Power Consumption dataset. It downloads the dataset, processes it, and plots the daily average of global active power.

## 🔍 Features

- Downloads and extracts the dataset from UCI ML Repository
- Cleans and parses data using Pandas
- Aggregates power usage by day
- Visualizes daily electricity usage trend

## 📈 Visualization

The script plots a time series graph of daily average power usage (kilowatts).

## 🚀 How to Run

1. Install dependencies:
   ```
   pip install pandas matplotlib
   ```

2. Run the script:
   ```
   python power_analysis.py
   ```

## 📂 Dataset Source

[UCI ML Repository - Household Power Consumption](https://archive.ics.uci.edu/ml/machine-learning-databases/00235/)
